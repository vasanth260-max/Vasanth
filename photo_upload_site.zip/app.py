from flask import Flask, render_template, request
import os

app = Flask(__name__)

UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    name = request.form['name']
    files = request.files.getlist('photos')

    user_folder = os.path.join(app.config['UPLOAD_FOLDER'], name)

    if not os.path.exists(user_folder):
        os.makedirs(user_folder)

    for file in files:
        if file.filename != "":
            file.save(os.path.join(user_folder, file.filename))

    return "Photos uploaded successfully!"

if __name__ == '__main__':
    app.run(debug=True)
